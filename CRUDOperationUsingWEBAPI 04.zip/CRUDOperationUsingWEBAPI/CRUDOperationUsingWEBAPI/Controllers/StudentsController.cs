﻿using CRUDOperationUsingWEBAPI.Model;
using CRUDOperationUsingWEBAPI.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDOperationUsingWEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly IStudentService _studentService;
        public StudentsController(IStudentService studentService)
        {
            _studentService = studentService;
        }
        [HttpGet("GetAllStudent")]
        public async Task<IActionResult> GetAllStudent()
        {
            try
            {
                var response = await _studentService.GetAllStudent();
                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpGet("GetStudentByStudentId/{StudentId}")]
        public async Task<IActionResult> GetStudentByStudentId(int StudentId)
        {
            try
            {
                var response = await _studentService.GetStudentByStudentId(StudentId);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpPost("AddStudent")]
        public async Task<IActionResult> AddStudent([FromBody] StudentDTO studentinfo)
        {
            try
            {
                var response = await _studentService.AddStudent(studentinfo);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpPut("UpdateStudent")]
        public async Task<IActionResult> UpdateStudent([FromBody] UpdatestudentDTO studentinfo)
        {
            try
            {
                if(studentinfo.StudentId > 0) 
                {
                    var response = await _studentService.UpdateStudent(studentinfo);
                    return Ok(response);
                }
                else
                {
                    return BadRequest("Please Pass Student Id");
                }
                
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpDelete("DeleteStudent")]
        public async Task<IActionResult> DeleteStudent([FromBody] DeleteStudentDTO studentinfo)
        {
            try
            {
                if (studentinfo.StudentId > 0)
                {
                    var response = await _studentService.DeleteStudent(studentinfo);
                    return Ok(response);
                }
                else
                {
                    return BadRequest("Please Pass Student Id");
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
    }
    
    
}

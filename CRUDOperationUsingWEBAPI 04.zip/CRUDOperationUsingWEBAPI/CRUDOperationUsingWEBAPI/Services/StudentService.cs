﻿using CRUDOperationUsingWEBAPI.Context;
using CRUDOperationUsingWEBAPI.Data;
using CRUDOperationUsingWEBAPI.Model;
using Microsoft.EntityFrameworkCore;

namespace CRUDOperationUsingWEBAPI.Services
{
    public class StudentService : IStudentService
    {
        private readonly StudentDBContext _context;
        public StudentService(StudentDBContext context)
        {
            _context = context;
        }
        public async Task<MainResponse> AddStudent(StudentDTO studentDTO)
        {
            var response = new MainResponse();
            try
            {
                if(_context.Student.Any(f=>f.Email.ToLower() == studentDTO.Email.ToLower())) 
                {
                    response.ErrorMessage = "Student Is Already exist with this Email";
                    response.IsSuccess = false;
                }
                else
                {
                    await _context.AddAsync(new Student
                    {
                        
                        Email = studentDTO.Email,
                        Address = studentDTO.Address,
                        LastName = studentDTO.LastName,
                        Gender = studentDTO.Gender,
                        FirstName = studentDTO.FirstName,


                    });
                    await _context.SaveChangesAsync();
                    response.IsSuccess = true;
                    response.Content = "student Added";
                }
               
               
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.IsSuccess = false;
            }
            return response;
        }

        public async Task<MainResponse> DeleteStudent(DeleteStudentDTO studentDTO)
        {
            var response = new MainResponse();
            try
            {
                var existingStudent = _context.Student.Where(f => f.StudentId == studentDTO.StudentId).FirstOrDefault();
                if (existingStudent != null)
                {
                    _context.Remove(existingStudent);
                    await _context.SaveChangesAsync();

                    response.IsSuccess = true;
                    response.Content = "Student info deleted";
                }
                else
                {
                    response.IsSuccess = false;
                    response.Content = "Student Info Not Found With specific StudentId";
                }
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.IsSuccess = false;
            }
            return response;
        }

        public async Task<MainResponse> GetAllStudent()
        {
            var response = new MainResponse();
            try
            {
                response.Content = await _context.Student.ToListAsync();
                response.IsSuccess = true;
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.IsSuccess = false;
            }
            return response;
        }

        public async Task<MainResponse> GetStudentByStudentId(int StudentId)
        {
            var response = new MainResponse();
            try
            {
                response.Content = await _context.Student.Where(f => f.StudentId == StudentId).FirstOrDefaultAsync();
                response.IsSuccess = true;
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.IsSuccess = false;
            }
            return response;
        }

        public async Task<MainResponse> UpdateStudent(UpdatestudentDTO studentDTO)
        {
            var response = new MainResponse();
            try
            {
                var existingStudent = _context.Student.Where(f => f.StudentId== studentDTO.StudentId).FirstOrDefault();
                if(existingStudent != null)
                {
                    existingStudent.Address = studentDTO.Address;
                    existingStudent.LastName = studentDTO.LastName; 
                    existingStudent.FirstName = studentDTO.FirstName;
                    await _context.SaveChangesAsync();

                    response.IsSuccess = true;
                    response.Content = "Recored Updated";
                }
                else
                {
                    response.IsSuccess = false;
                    response.Content = "Student Info Not Found With specific StudentId";
                }
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.IsSuccess = false;
            }
            return response;
        }
    }
}

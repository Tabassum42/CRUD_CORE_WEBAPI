﻿using System;
using System.Collections.Generic;
using CRUDOperationUsingWEBAPI.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CRUDOperationUsingWEBAPI.Context;

public partial class StudentDBContext : IdentityDbContext<Users> //hajar hajar kahini
{

    public StudentDBContext(DbContextOptions<StudentDBContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Student> Student { get; set; }



    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {

        //modelBuilder.Entity<Student>(entity =>
        //{
        //    entity.Property(e => e.StudentId).HasColumnName("studentID");
        //});

        //modelBuilder.Entity<Users>(entity =>
        //{
        //    entity.Property(e => e.FirstName).HasColumnName("FirstName");
        //});
        base.OnModelCreating(modelBuilder);
        //base.OnModelCreatingPartial(modelBuilder); --kahini no 1
        modelBuilder.Entity<IdentityUserLogin<string>>().HasKey(l => new { l.LoginProvider, l.ProviderKey }); //for primary key entity.
        //modelBuilder.Entity<IdentityUserLogin<int>>().HasNoKey();---kahini no2
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

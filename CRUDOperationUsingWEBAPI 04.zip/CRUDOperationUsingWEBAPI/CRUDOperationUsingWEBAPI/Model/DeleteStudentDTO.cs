﻿namespace CRUDOperationUsingWEBAPI.Model
{
    public class DeleteStudentDTO
    {
        public int StudentId { get; set; }
    }
}

﻿namespace CRUDOperationUsingWEBAPI.Model
{
    public class CreateRoleDTO
    {
        public string RoleName { get; set; }
    }
}

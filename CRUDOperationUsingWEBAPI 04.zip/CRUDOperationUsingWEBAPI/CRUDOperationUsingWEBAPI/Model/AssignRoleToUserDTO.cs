﻿namespace CRUDOperationUsingWEBAPI.Model
{
    public class AssignRoleToUserDTO
    {
        public string Email { get; set; }
        public string RoleName { get; set; }
    }
}

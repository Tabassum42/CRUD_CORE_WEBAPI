﻿namespace CRUDOperationUsingWEBAPI.Model
{
    public class DeleteUserDTO
    {
        public string Email { get; set; }
    }
}

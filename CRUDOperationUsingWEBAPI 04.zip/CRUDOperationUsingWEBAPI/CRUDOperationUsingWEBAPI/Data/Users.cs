﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace CRUDOperationUsingWEBAPI.Data
{
    
    public class Users : IdentityUser
    {
        [MaxLength(100)]
        public string FirstName { get; set; } = null!;
        [MaxLength(100)]
        public string LastName { get; set; } = null!;
       
        [MaxLength(6)]
        public string Gender { get; set; } = null!;
        public string? Address { get; set; }
    }
}

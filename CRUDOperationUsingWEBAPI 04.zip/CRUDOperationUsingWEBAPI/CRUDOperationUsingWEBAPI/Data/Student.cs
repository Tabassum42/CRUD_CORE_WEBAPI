﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CRUDOperationUsingWEBAPI.Data;

public partial class Student
{
    [Key]
    public int StudentId { get; set; }
    [MaxLength(100)]
    public string FirstName { get; set; } = null!;
    [MaxLength(100)]
    public string LastName { get; set; } = null!;
    [MaxLength(50)]
    public string Email { get; set; } = null!;
    [MaxLength(6)]
    public string Gender { get; set; } = null!;
    public string? Address { get; set; }
}
